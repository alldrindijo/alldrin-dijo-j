n=int(input("enter the number:"))
if(n%3==0 and n%5==0):
    print("divisible by 3 and 5")
else:
    print("not divisible by 3 and 5")
    
