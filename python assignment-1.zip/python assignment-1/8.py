for i in range(1,100,2):
    print(i)
