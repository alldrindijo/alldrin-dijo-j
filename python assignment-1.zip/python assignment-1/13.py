n=int(input("ENTER PERCENTAGE:"))
if(n>70):
    name=str(input("ENTER NAME:"))
    dep=str(input("ENTER DEPARTMENT"))
    loc=str(input("ENTER LOCATION"))
    print("your eligible")
else:
    print("not eligible")
