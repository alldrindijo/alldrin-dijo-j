correct_pass="password123"
while True:
    password=input("enter the password:")
    if password==correct_pass:
        print("ACCESS GRANTED")
        break
else:
    print("incorrect password try again")
    
