num=int(input("enter the number:"))
if(num>0):
    print("positive number")
if(num<0):
    print("negative number")
else:
    print("the number is zero")
    
