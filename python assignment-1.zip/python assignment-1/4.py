for i in range(1,37):
    if(i%6==0):
        print(i)
