mark=int(input("enter your mark:"))
if(mark>35):
    print("pass")
else:
    print("fail")
