num=int(input("enter the numbers:"))
if(num>1):
    for i in range(2,num):
        if num*i==0:
            print("not a prime number")
else:
    print("prime number")
    
