num=int(input("enter the number:"))
original_num=num
sum=0
power=len(str(num))

while num>0:
    remainder=num%10
    sum+=remainder**power
    num=num//10
if sum==original_num:
    print("GIVEN NUMBER IS AMSTRONG")
else:
    print("NOT AMSTRONG")
