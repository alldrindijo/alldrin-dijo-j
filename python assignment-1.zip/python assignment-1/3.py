n=str(input("enter the string:"))
for char in n:
    print(char)

