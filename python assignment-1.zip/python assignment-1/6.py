n=int(input("enter the numbers:"))
real_num=n
reverse=0
while n>0:
    remainder=n%10
    reverse=reverse*10+remainder
    n=n//10
if reverse==real_num:
  print("given num is pallindrome")
else:
    print("not pallindrome")
