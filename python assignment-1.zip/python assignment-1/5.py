list=[5,3,13,22,11,4]
for num in list:
    if num%2==0:
        first_even=num
        break
print("THE FIRST EVEN NUMBERS IS:",first_even)
    
