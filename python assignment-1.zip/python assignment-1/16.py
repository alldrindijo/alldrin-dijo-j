a=int(input("enter tamil mark:"))
b=int(input("enter engish mark:"))
c=int(input("enter maths mark:"))
d=int(input("enter science mark:"))
e=int(input("enter social mark:"))
avrg=a+b+c+d+e
if(avrg>35):
    print("good to go")
else:
    print("additional class is required")
    
            
