for i in range(1,59,2):
    print(i)
